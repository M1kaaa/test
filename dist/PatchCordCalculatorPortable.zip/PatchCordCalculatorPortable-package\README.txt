﻿Portable single-file package

Run:
- PatchCordCalculator.exe

Notes:
- Browser opens automatically
- Keep console window open while app is running
- Press Ctrl+C in console to stop
